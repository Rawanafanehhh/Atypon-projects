public enum CardType {
    ZERO,
    ONE,
    TWO,
    THREE,
    FOUR,
    FIVE,
    SIX,
    SEVEN,
    EIGHT,
    NINE,
    REVERSE,
    SKIP,
    DRAW_TWO,
    WILD,
    WILD_DRAW_FOUR
}