public enum CardColor {
    RED,
    BLUE,
    GREEN,
    YELLOW,
    NONE
}
