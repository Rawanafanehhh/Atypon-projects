public class GameDriver {
    public static void main(String[] args) throws Exception {
        Game game = new UnoGameVariation();
        game.play();
    }
}
