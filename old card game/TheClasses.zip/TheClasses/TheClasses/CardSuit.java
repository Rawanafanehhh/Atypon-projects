public enum CardSuit {
    SPADES, HEARTS, DIAMONDS, CLUBS
}

