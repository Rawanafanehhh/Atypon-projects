package com.example.enterdata;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EnterDataApplication {

    public static void main(String[] args) {
        SpringApplication.run(EnterDataApplication.class, args);
    }

}