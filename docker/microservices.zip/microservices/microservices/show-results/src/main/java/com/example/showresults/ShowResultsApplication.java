package com.example.showresults;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ShowResultsApplication {

    public static void main(String[] args) {
        SpringApplication.run(ShowResultsApplication.class, args);
    }

}