package com.Queries.QueriesManegers.Validators.syntax;

public interface QueryValidator {
    public boolean isValidQuery();
}