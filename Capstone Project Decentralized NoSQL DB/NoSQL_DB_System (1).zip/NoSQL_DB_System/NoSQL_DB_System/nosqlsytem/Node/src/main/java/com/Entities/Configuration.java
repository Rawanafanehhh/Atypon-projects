package com.Entities;

public class Configuration {

    private Schema schema;

    public Configuration(Schema schema) {
        this.schema = schema;
    }

    public Schema getSchema() {
        return schema;
    }


}