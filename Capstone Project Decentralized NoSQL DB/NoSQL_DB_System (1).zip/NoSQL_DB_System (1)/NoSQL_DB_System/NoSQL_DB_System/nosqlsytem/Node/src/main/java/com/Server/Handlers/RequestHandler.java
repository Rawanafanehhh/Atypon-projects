package com.Server.Handlers;

import java.io.IOException;

public interface RequestHandler {
    public void handle() throws IOException;
}